{
  "assinatura": "5c8951d33e98946b4bd34d5fa9973fc8f7074e8d3792402dc773f009fcf6e98f",
  "payload": {
    "algoritmo": "HMAC-SHA256",
    "cnpj": "04671382000136",
    "codempresa": "1",
    "codvendedor": "001",
    "hash_assinatura": "4940ba0e9bd11dcc5badb4ec3e402d6d88a98de58631d9e64c3e1068315b11c5",
    "hash_fotos": {},
    "hash_pdf": "",
    "hash_txt": "5b378d1fd331601386236ee62f7b189ff29c1e73d1f972864c332150347dd9c8",
    "idcelular": "a3e9e3a0a4659652",
    "modelo": "MOD1",
    "nome_arquivo": "MOD1_1_001_04671382000136_170720260922.zip",
    "serial": "eyJjbnBqcyI6WyIwNDY3MTM4MjAwMDEzNiIsIjA0NjcxMzgyMDAwMzA2Il0sImlkc19jZWx1bGFyIjpbImEzZTllM2EwYTQ2NTk2NTIiLCJBTEVYU0FOREVSVEVTVEVJRCJdLCJ2YWxpZGFkZSI6IjIwMjYtMDctMzEiLCJub21lX2NsaWVudGUiOiJHVUlEQVVUTyIsInNxbF9zZXJ2aWRvciI6IkNFT1NPRlQtU0VSVjEiLCJzcWxfYmFuY28iOiJHVUlEQVVUTyIsImdlcmFkb19lbSI6IjIwMjYtMDctMDlUMTA6NDU6NDItMDM6MDAifQ.6ZmUsCZAS9tJIfmde_Ms2kR_wdGfyTW6kp_QzcqCUrc",
    "timestamp": "2026-07-17T09:22:31",
    "versao": "26.07.16 rev. 6"
  }
}