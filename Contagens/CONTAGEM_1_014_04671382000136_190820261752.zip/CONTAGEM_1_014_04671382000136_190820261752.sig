{
  "assinatura": "01ea479a3be1e4e2f9bfd3d8d64da12e31bea17b94c08033884939f38d0e30f0",
  "assinatura_rsa": "q1z00P0B05hA+EluRiQwIElx7A2L/RXEiCfG5SRKGHFFvNwnkkCAIpitWx/pK0SReTcLdAJqYl7RYshsNUfomFlcqYLPvHAFukpoUgRa8wSf2UgVcPfLp+bImorBEEmWGBxb/lvu9N0LuOMaYudc2zmyJCSnK+QwA+wsksQf1cllpaQrRby9wL667QL9wh5Fh4pxLPcaHkFhukdGckTavEv2DBQr77vRn9/G47bMIs0SBg5ivu0jcWhTUCfxfo3gsRIVjAr77xo+lpaCZEonGOmmfw8T0zB/kNbeCRSIbLOkycWk0y5PnPU+Kml2KFgsTqfx+ozJprnx+zJiq6IPSg==",
  "payload": {
    "algoritmo": "HMAC-SHA256",
    "algoritmo_rsa": "RSA-2048/PKCS1v15-SHA256",
    "cnpj": "04671382000136",
    "codempresa": "1",
    "codvendedor": "014",
    "hash_assinatura": "82ca43f8ff14be71edf669f3ea6bc42c0e519b59a78a6ba17d29919cc8743fd4",
    "hash_db": "e72c8ce36fe7819e754086fa94d5f81554f998ae174d46224ac3886d1c66d459",
    "hash_fotos": {},
    "hash_metricas": "",
    "hash_pdf": "8413c0e3fe1107dca3cc33aa7d1ab517c897a061cd60e4305945c0def2f26232",
    "idcelular": "97fe33f6f301aa86",
    "modelo": "CONTAGEM",
    "nome_arquivo": "CONTAGEM_1_014_04671382000136_190820261752.zip",
    "serial": "eyJjbnBqcyI6WyIwNDY3MTM4MjAwMDEzNiIsIjA0NjcxMzgyMDAwMzA2Il0sIm5vbWVzIjpbIkdVSURBVVRPIiwiR3VpZGF1dG8gRGVww7NzaXRvIl0sImlkc19jZWx1bGFyIjpbImEzZTllM2EwYTQ2NTk2NTIiLCI5N2ZlMzNmNmYzMDFhYTg2Il0sInZhbGlkYWRlIjoiMjAyNi0wOC0yMSIsIm5vbWVfY2xpZW50ZSI6IkdVSURBVVRPLEd1aWRhdXRvIERlcMOzc2l0byIsInNxbF9zZXJ2aWRvciI6IkNFT1NPRlQtU0VSVjEiLCJzcWxfYmFuY28iOiJHVUlEQVVUTyIsInRpcG9fbGljZW5jYSI6IlBybyIsImdlcmFkb19lbSI6IjIwMjYtMDgtMTdUMTU6NTI6MzgtMDM6MDAifQ.RI__GqlWteXYgAFoWOT43UHojyQbVM1WOe9Nan3yVR0",
    "timestamp": "2026-08-19T17:52:19",
    "versao": "26.08.19 rev. 4"
  }
}