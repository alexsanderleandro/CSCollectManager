{
  "assinatura": "8977dbb727ece8236b1e3eb2bf5b77a83b3dc404a183e78419ff7b06526637e2",
  "payload": {
    "algoritmo": "HMAC-SHA256",
    "cnpj": "65381113000120",
    "codempresa": "1",
    "codvendedor": "043",
    "hash_assinatura": "3ec31240639975b0aea6e7e793db3f564effdf6b370421ac0e3d22ce7f1f3a2c",
    "hash_fotos": {},
    "hash_pdf": "e68bf08d0af05d9b3f6cc3fcfee32fcf63a9f2b1f5ae31bdf5d7f598890ff239",
    "hash_txt": "33ed8ccac31e299c859e2ee1549ee2e58c9b05abfe88933cf4a034b78ec27080",
    "idcelular": "a3e9e3a0a4659652",
    "modelo": "MOD1",
    "nome_arquivo": "MOD1_1_043_65381113000120_080520261017.zip",
    "serial": "d2bd9a450500c2e851d049c5fb846f44.KR9BAHRkz4EN_WDZmCM8uEChuNj6DYpGvzZG-csxmdE",
    "timestamp": "2026-05-08T10:17:59",
    "versao": "26.05.07 rev. 4"
  }
}