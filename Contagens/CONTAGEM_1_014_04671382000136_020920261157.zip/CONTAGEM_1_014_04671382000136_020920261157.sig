{
  "assinatura": "bd7b09ccc1e8a6222f2f1bc59fa4d85633e3cf9c42be01c8573a37c456f8901b",
  "assinatura_rsa": "w/Oc+WI8J4+0dSyynRKUlr+77fwHyjNKSZgKbPoEILa4b8AVT/2FWiWZ1nTf5pV4snMzStmi8uCI40SySghEu4F/BG7U3hk8b678DJTovI2a8n1RGIEJEKGZ327nHsZ+1FPRowaWvVsBPLIlNgkAo9Nq2QEsQbikOiV2CrLzDv4JSCjdy0yZ1bOKL9egc94x/yAhd8bf1kHYkrMYS+k+vcM7DVybruuip5j8yF3vbf2KGI7htLY6MyMZJcYdOizTJQ+DmnRPbPz79n+pTJMSsij0tkqVd1F9X5Iw7a9KZ/tlUBT9Fkg3uVxlJ6P8IBYqBfR0DN+fssQjElQcCCuSzA==",
  "payload": {
    "algoritmo": "HMAC-SHA256",
    "algoritmo_rsa": "RSA-2048/PKCS1v15-SHA256",
    "cnpj": "04671382000136",
    "codempresa": "1",
    "codvendedor": "014",
    "hash_assinatura": "69c74eff2875015ae41e26924ed84bf701b8468c8c0214ef044ccfa24cf1a764",
    "hash_db": "9baa5516ea2ab333ec22bd49790b9883831a2b585486dbe1c7d3488dee5e9e80",
    "hash_fotos": {},
    "hash_metricas": "b0df662520649b98c6554c532d8f5430d02d0d40f7f02dc51ae6e7618c7fa56a",
    "hash_pdf": "e7842cd49dd790dcaa3e95ca155287a21c30153a5acd1b8057563d18de81873d",
    "idcelular": "97fe33f6f301aa86",
    "modelo": "CONTAGEM",
    "nome_arquivo": "CONTAGEM_1_014_04671382000136_020920261157.zip",
    "serial": "eyJjbnBqcyI6WyIwNDY3MTM4MjAwMDEzNiIsIjA0NjcxMzgyMDAwMzA2Il0sIm5vbWVzIjpbIkdVSURBVVRPIiwiR3VpZGF1dG8gRGVww7NzaXRvIl0sImlkc19jZWx1bGFyIjpbImEzZTllM2EwYTQ2NTk2NTIiLCI5N2ZlMzNmNmYzMDFhYTg2Il0sInZhbGlkYWRlIjoiMjAyNi0wOS0wNCIsIm5vbWVfY2xpZW50ZSI6IkdVSURBVVRPLEd1aWRhdXRvIERlcMOzc2l0byIsInNxbF9zZXJ2aWRvciI6IkNFT1NPRlQtU0VSVjEiLCJzcWxfYmFuY28iOiJHVUlEQVVUTyIsInRpcG9fbGljZW5jYSI6IlBybyIsImdlcmFkb19lbSI6IjIwMjYtMDgtMzFUMTI6MDI6NTQtMDM6MDAifQ.SF-BQLrj-UGwdck8daN7Ft_wb6KM6nit1PgvJedQzaw",
    "timestamp": "2026-09-02T11:57:50",
    "versao": "26.09.02 rev. 1"
  }
}