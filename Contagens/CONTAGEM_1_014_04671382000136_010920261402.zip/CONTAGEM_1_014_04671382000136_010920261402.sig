{
  "assinatura": "b062c3b3da68437e3fae61912db4a6cf048bb2f66975226172cdd237facb046d",
  "assinatura_rsa": "y/o/dT/oXSD0Iixpb+03Md15RmtJYwqHKP4KicMVlo5wvmAIqLlj/NXRCRjfFb+SyPQbXrfyQWb1sgN7feVKPtNwUUp6d5ualwuLa9oPbcRYc47MQxxVXWwD2xgqo9xpb0Na5ByXp0MDWEsAsRS/ycUkyFU6tIZZJQGagkYjqLKrbbSdFk36cIBwadXZ26cnQrZa624twIHfoOfOAq6QZUO0dIu1dsh+3arxUFS3+4q4lfPHewWFQyDDGHpS5BW4tybqvqcJdoWLyMI9p/TYtyL5HFlHPMtw7AGXWDJTF8vTgz3+vTKadhd2iGk9g9USTbqSmh+szbhzJiVXjdSZkQ==",
  "payload": {
    "algoritmo": "HMAC-SHA256",
    "algoritmo_rsa": "RSA-2048/PKCS1v15-SHA256",
    "cnpj": "04671382000136",
    "codempresa": "1",
    "codvendedor": "014",
    "hash_assinatura": "81adc5214f7510fc5c67ae7472563f302afa83e80e77241127b4dc5fd166293c",
    "hash_db": "5bec71df5e0c5148842aa7d411cb43d9936fb887dc6c9a5063866b69429a7634",
    "hash_fotos": {},
    "hash_metricas": "9bc1b35d7a9b6047af57d8b6294230a0e84d56e263d5a768111620dc7dd85662",
    "hash_pdf": "4cd3ce61f9f1a8b63249b1a0091397aaa4c39ab84ad6a9b8a0e225761d86bb1b",
    "idcelular": "97fe33f6f301aa86",
    "modelo": "CONTAGEM",
    "nome_arquivo": "CONTAGEM_1_014_04671382000136_010920261402.zip",
    "serial": "eyJjbnBqcyI6WyIwNDY3MTM4MjAwMDEzNiIsIjA0NjcxMzgyMDAwMzA2Il0sIm5vbWVzIjpbIkdVSURBVVRPIiwiR3VpZGF1dG8gRGVww7NzaXRvIl0sImlkc19jZWx1bGFyIjpbImEzZTllM2EwYTQ2NTk2NTIiLCI5N2ZlMzNmNmYzMDFhYTg2Il0sInZhbGlkYWRlIjoiMjAyNi0wOS0wNCIsIm5vbWVfY2xpZW50ZSI6IkdVSURBVVRPLEd1aWRhdXRvIERlcMOzc2l0byIsInNxbF9zZXJ2aWRvciI6IkNFT1NPRlQtU0VSVjEiLCJzcWxfYmFuY28iOiJHVUlEQVVUTyIsInRpcG9fbGljZW5jYSI6IlBybyIsImdlcmFkb19lbSI6IjIwMjYtMDgtMzFUMTI6MDI6NTQtMDM6MDAifQ.SF-BQLrj-UGwdck8daN7Ft_wb6KM6nit1PgvJedQzaw",
    "timestamp": "2026-09-01T14:02:38",
    "versao": "26.09.01 rev. 1"
  }
}