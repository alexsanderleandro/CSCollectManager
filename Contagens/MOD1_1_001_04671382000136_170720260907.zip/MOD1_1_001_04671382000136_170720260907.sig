{
  "assinatura": "1d54c8d3e5dc940574537005d65c63000037dd695056cc839688636cfa22e0a7",
  "payload": {
    "algoritmo": "HMAC-SHA256",
    "cnpj": "04671382000136",
    "codempresa": "1",
    "codvendedor": "001",
    "hash_assinatura": "995c781c867c04c76a9e561e9648d8522cd2f2e5036dec218035dd1ef231e570",
    "hash_fotos": {},
    "hash_pdf": "",
    "hash_txt": "92bb5d14e3c1d3807cb699921c50f30bd8e010f831b47cef0534b180f2e07894",
    "idcelular": "a3e9e3a0a4659652",
    "modelo": "MOD1",
    "nome_arquivo": "MOD1_1_001_04671382000136_170720260907.zip",
    "serial": "eyJjbnBqcyI6WyIwNDY3MTM4MjAwMDEzNiIsIjA0NjcxMzgyMDAwMzA2Il0sImlkc19jZWx1bGFyIjpbImEzZTllM2EwYTQ2NTk2NTIiLCJBTEVYU0FOREVSVEVTVEVJRCJdLCJ2YWxpZGFkZSI6IjIwMjYtMDctMzEiLCJub21lX2NsaWVudGUiOiJHVUlEQVVUTyIsInNxbF9zZXJ2aWRvciI6IkNFT1NPRlQtU0VSVjEiLCJzcWxfYmFuY28iOiJHVUlEQVVUTyIsImdlcmFkb19lbSI6IjIwMjYtMDctMDlUMTA6NDU6NDItMDM6MDAifQ.6ZmUsCZAS9tJIfmde_Ms2kR_wdGfyTW6kp_QzcqCUrc",
    "timestamp": "2026-07-17T09:07:05",
    "versao": "26.07.16 rev. 6"
  }
}