{
  "assinatura": "b0d372fcd360ffffb948d05dc440f150f6de18cd12ccd83e18a1a5a773aad368",
  "assinatura_rsa": "uA3TgbPr1+ZHujloDcXXRVxFpuS+Sw8OENb9ietsyHFYHoTVmUZi4O1/DHcPHy8hEsVajaCAAhzaSD3qWrxWa5WfZg9Q+SlKg4LwxfehkPz+1QPSIjeZkEnxZebn2YE/QfLMCeSwAfgy9MfG+6nKgXlyV8ZTWijjagdTYMCrglsUItPURlan1/CPkab5c+ayH97LPpOzHyb81r9J9eGQ5RK7UYBQ/xmY01n6iifdPvT4rVwLfU+o0uQBZ9HAWgNCFvfizfOhJLQ4C1pbbaktYnxiku67qXfF66ZLKNHExIlvk+wkNlG3C86UjXsakBNiyI979dPaou2cN0Cl765hJg==",
  "payload": {
    "algoritmo": "HMAC-SHA256",
    "algoritmo_rsa": "RSA-2048/PKCS1v15-SHA256",
    "cnpj": "04671382000136",
    "codempresa": "1",
    "codvendedor": "008",
    "hash_assinatura": "04a41c2cbbd1bdbd3618eb1f0e997c4dbcda27f927a4c49b3f806fcc209bf770",
    "hash_db": "a9ac4d80a7e19ee7a22cbeb9db9075fef79cc6cfcab1744f6a329a298eb28633",
    "hash_fotos": {},
    "hash_metricas": "",
    "hash_pdf": "9fd2f0c684fd3c871748d9f1b1d86a762fac62c2fe7c26bea47ffcb51afe102a",
    "idcelular": "97fe33f6f301aa86",
    "modelo": "CONTAGEM",
    "nome_arquivo": "CONTAGEM_1_008_04671382000136_080820261341.zip",
    "serial": "eyJjbnBqcyI6WyIwNDY3MTM4MjAwMDEzNiIsIjA0NjcxMzgyMDAwMzA2Il0sIm5vbWVzIjpbIkdVSURBVVRPIiwiR3VpZGF1dG8gRGVww7NzaXRvIl0sImlkc19jZWx1bGFyIjpbImEzZTllM2EwYTQ2NTk2NTIiLCI5N2ZlMzNmNmYzMDFhYTg2Il0sInZhbGlkYWRlIjoiMjAyNi0wOC0xNCIsIm5vbWVfY2xpZW50ZSI6IkdVSURBVVRPLEd1aWRhdXRvIERlcMOzc2l0byIsInNxbF9zZXJ2aWRvciI6IkNFT1NPRlQtU0VSVjEiLCJzcWxfYmFuY28iOiJHVUlEQVVUTyIsInRpcG9fbGljZW5jYSI6IlBybyIsImdlcmFkb19lbSI6IjIwMjYtMDgtMDdUMTM6Mjk6MzAtMDM6MDAifQ.x0GNmSaN1iL8RDnyM_9oohCVWKbQhxgUeH3JQLVOkYw",
    "timestamp": "2026-08-08T13:41:51",
    "versao": "26.08.07 rev. 5"
  }
}