{
  "assinatura": "fc563b06c18a4939019009bd77a0f15c31772883d6dd1ae503db1716ffe78033",
  "assinatura_rsa": "Qu2XlsmvnMkQasGQgmmJY8kqV9GaNYm4Jc1dRahVVDDIT99iY1zPwGv1Vc7Voj0ZuzQ8wwksHF+/EhMqJj/dmZNlBniFPA/3Vn/YTPXRLCPpR1SzintE6gD23JLl7REWY/EU11NnlaGl+GlL4V1kcrQL4XFR/tEAAtiOyDOIoj1/u00hyFyAnhUV749Ci4yc3Gry+tt6RgYxb8kjV7OxEXwISfuXGnEAtU4tCFQwsmja3HiumB/yZJhmB0INzkmg8ubqeF9RZMgoVQfKpwbgMP1i+EEGcxjQ1kTO9GfVluKF+q8Hp4mKUkvwY7d9qLvTDfvqfP+as+icPXA73uyUGg==",
  "payload": {
    "algoritmo": "HMAC-SHA256",
    "algoritmo_rsa": "RSA-2048/PKCS1v15-SHA256",
    "cnpj": "04671382000136",
    "codempresa": "1",
    "codvendedor": "014",
    "hash_assinatura": "7475836c66c8df2e84c360c56212ee27d0c040751e295b85844233b1e2877d2a",
    "hash_db": "570f9740b6a5cd5ce3390ac17d68f2c23e34e15069f678020a938edb947ec5a0",
    "hash_fotos": {},
    "hash_metricas": "33a1ae32bd2386a730ce8c535da895298f3b5d47c1daa5283ab739e500ec8aff",
    "hash_pdf": "cae5d8a507b0bb7ad5f8149d9ac991740a77fda23d80ada8a513ac017084f9e5",
    "idcelular": "97fe33f6f301aa86",
    "modelo": "CONTAGEM",
    "nome_arquivo": "CONTAGEM_1_014_04671382000136_040920261100.zip",
    "serial": "eyJjbnBqcyI6WyIwNDY3MTM4MjAwMDEzNiIsIjA0NjcxMzgyMDAwMzA2Il0sIm5vbWVzIjpbIkdVSURBVVRPIiwiR3VpZGF1dG8gRGVww7NzaXRvIl0sImlkc19jZWx1bGFyIjpbImEzZTllM2EwYTQ2NTk2NTIiLCI5N2ZlMzNmNmYzMDFhYTg2Il0sInZhbGlkYWRlIjoiMjAyNi0wOS0wNCIsIm5vbWVfY2xpZW50ZSI6IkdVSURBVVRPLEd1aWRhdXRvIERlcMOzc2l0byIsInNxbF9zZXJ2aWRvciI6IkNFT1NPRlQtU0VSVjEiLCJzcWxfYmFuY28iOiJHVUlEQVVUTyIsInRpcG9fbGljZW5jYSI6IlBybyIsImdlcmFkb19lbSI6IjIwMjYtMDgtMzFUMTI6MDI6NTQtMDM6MDAifQ.SF-BQLrj-UGwdck8daN7Ft_wb6KM6nit1PgvJedQzaw",
    "timestamp": "2026-09-04T11:00:13",
    "versao": "26.09.04 rev. 1"
  }
}