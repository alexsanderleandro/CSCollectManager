{
  "assinatura": "57b361d2cc703339262e5a0fbfa297f8d8859ab4ffb57b875b4a015d664d449f",
  "assinatura_rsa": "L9HRqmy9y3G3Nj/QnakKoPlb7FtLTXPojD4qFwgFMz6sGZR1U+u12Ei729iWu+79LudZzwl/kL8wA+wlI96na9btygGsl5mgF0KnNXgfK0IGEgf96ggXJbNEb0dUW2J7IxiybRycCaTzr5LZVQhDhxlLcAaYo+HFu8k+R4F2LE/ULwMw1WBc/ypDXDcp9bAzk5Da352fj/N4F7c+5asJUkQWrRPfCk1Q5ljXDbCIuaKWEAnqf1wexBOyCWgIHhLFYa1bS8hRg3AyssjT4IACeXj2mJ7oidoHQ3o6rJPtK4y1EosZ1rqaIJcOxJpfl/kkpkojdlLZM7k+OfWK8BX46g==",
  "payload": {
    "algoritmo": "HMAC-SHA256",
    "algoritmo_rsa": "RSA-2048/PKCS1v15-SHA256",
    "cnpj": "04671382000136",
    "codempresa": "1",
    "codvendedor": "014",
    "hash_assinatura": "f6d6cdb8ea345d47af564dc822543dd23061de94e320f1fb95238df97ff5bec6",
    "hash_db": "5f69ffba02bba2685dbe5ebefb0125c4cb1d96923bf8e2385f8cabb447ca0da0",
    "hash_fotos": {},
    "hash_metricas": "6be76e2ea46d32cef5e889aacdd46b0210d888f18674d24694aba97a9d98ea2a",
    "hash_pdf": "ba1dc3452c4d343d4e700ce91f19828964be4d0f46fc804a7081408b51a35303",
    "idcelular": "97fe33f6f301aa86",
    "modelo": "CONTAGEM",
    "nome_arquivo": "CONTAGEM_1_014_04671382000136_170920261806.zip",
    "serial": "eyJjbnBqcyI6WyIwNDY3MTM4MjAwMDEzNiIsIjA0NjcxMzgyMDAwMzA2Il0sIm5vbWVzIjpbIkdVSURBVVRPIiwiR3VpZGF1dG8gRGVww7NzaXRvIl0sImlkc19jZWx1bGFyIjpbImEzZTllM2EwYTQ2NTk2NTIiLCI5N2ZlMzNmNmYzMDFhYTg2Il0sInZhbGlkYWRlIjoiMjAyNi0wOS0xOSIsIm5vbWVfY2xpZW50ZSI6IkdVSURBVVRPLEd1aWRhdXRvIERlcMOzc2l0byIsInNxbF9zZXJ2aWRvciI6IkNFT1NPRlQtU0VSVjEiLCJzcWxfYmFuY28iOiJHVUlEQVVUTyIsInRpcG9fbGljZW5jYSI6IlBybyIsImdlcmFkb19lbSI6IjIwMjYtMDktMTRUMDk6MTY6MzctMDM6MDAifQ.b1R-1SpNCSV1eJRBf9qCUV-RV6kUYQxijmSzRwh0KIY",
    "timestamp": "2026-09-17T18:06:21",
    "versao": "26.09.17 rev. 2"
  }
}