{
  "assinatura": "174c5b9bf4e6ab1cdd59c95c80d85663c49bda7d0b04a2170b0b65e35cfcf943",
  "assinatura_rsa": "f4ApR61BAoqsjKQtzgq5pa1Rzt3nOaqragyjXSctYZVuMoWxehPuoh8pZM8jiA29qBhiOg9NF/jlXN36zBsr8vOTqDg6GLHJTz16s8I6Q9r1yItDclXxK1nrUHB+Yr0GAaDOWqAU4Q8sKAx6hRyL/LSZvYq9ZE2oHrBXDZPDikOu0gzTIXObxvV8eNwoYu+L2MA9cejCNj+sv1bbtk+llCBaAI6EzBouzpYl9/fikotmBvyJ3mGTqH/sJq68XiikRbqdSzowDZj6NqvKBctbeuzmt8sA3+1PudCAyowPiCB/1Ta/oCf4/tXOSFP26KqoImI4G0nEf2CLbxJmcOHFrw==",
  "payload": {
    "algoritmo": "HMAC-SHA256",
    "algoritmo_rsa": "RSA-2048/PKCS1v15-SHA256",
    "cnpj": "04671382000136",
    "codempresa": "1",
    "codvendedor": "014",
    "hash_assinatura": "cf2b9b526159295a799ba1d64c3345c9ee957ca34aa7ef2887aa4fcb29648e95",
    "hash_db": "7d0fa066964b2b4848484fd63b0b59f07244f3063b3293bcf7504177f376f2fd",
    "hash_fotos": {},
    "hash_metricas": "0a3c4200dbd5ae6d6280e7f5cb221697337477d84bf827a35d1d166a10aee527",
    "hash_pdf": "51cc254b574fe18f1cb65a6e540189728a87af27347acdf6376a67082b552347",
    "idcelular": "97fe33f6f301aa86",
    "modelo": "CONTAGEM",
    "nome_arquivo": "CONTAGEM_1_014_04671382000136_040920261400.zip",
    "serial": "eyJjbnBqcyI6WyIwNDY3MTM4MjAwMDEzNiIsIjA0NjcxMzgyMDAwMzA2Il0sIm5vbWVzIjpbIkdVSURBVVRPIiwiR3VpZGF1dG8gRGVww7NzaXRvIl0sImlkc19jZWx1bGFyIjpbImEzZTllM2EwYTQ2NTk2NTIiLCI5N2ZlMzNmNmYzMDFhYTg2Il0sInZhbGlkYWRlIjoiMjAyNi0wOS0wNCIsIm5vbWVfY2xpZW50ZSI6IkdVSURBVVRPLEd1aWRhdXRvIERlcMOzc2l0byIsInNxbF9zZXJ2aWRvciI6IkNFT1NPRlQtU0VSVjEiLCJzcWxfYmFuY28iOiJHVUlEQVVUTyIsInRpcG9fbGljZW5jYSI6IlBybyIsImdlcmFkb19lbSI6IjIwMjYtMDgtMzFUMTI6MDI6NTQtMDM6MDAifQ.SF-BQLrj-UGwdck8daN7Ft_wb6KM6nit1PgvJedQzaw",
    "timestamp": "2026-09-04T14:00:10",
    "versao": "26.09.04 rev. 3"
  }
}