{
  "assinatura": "1a81747c785dda264304805310f849e48fba01f2b09326108df3922a8dc1cac7",
  "assinatura_rsa": "ITi1EiP7MJG24AvyKXmOggW0dxrF5VuPeh98pmaPS7lmNnogGooiG7N7VssdKsDSsO0Cu/70Uqq0OseIkVuHRXFEeb1+OGmQwLFWcM57RZYD5q2sK8u+4Cl8ca4yfk1f97YM+l6HzyoUEVck+xyeaE9y9TKa1JT832JxO06oihHUyr+Y09JELMaGxEWS9pt560JdYT4u1ItXIGGkJGBh/J7kaV4FegxhSpAE8G76B5XlAySKdH2bSEd3ncxWGDzIfw7hzA9Sb0j25uD+ee3b5P4naOmd8er8IusWw0GVK6jY3mLcDaTzSSH+4Sk8NXL7aTC4aDAdMUGC/gHS38BX4g==",
  "payload": {
    "algoritmo": "HMAC-SHA256",
    "algoritmo_rsa": "RSA-2048/PKCS1v15-SHA256",
    "cnpj": "04671382000136",
    "codempresa": "1",
    "codvendedor": "014",
    "hash_assinatura": "a062b35751754b1e2999a4de7283acfe16c1ebc9aec12b721ffad6194fb80a51",
    "hash_db": "7df7fb38c8823aadf0e889fa654fa1ae406fea0223a7805e79bf6b5ddefbce01",
    "hash_fotos": {},
    "hash_metricas": "c5f0d5c46ce44481f888ade9eccea8b21f2450ec549711ca6e3ff63375783a70",
    "hash_pdf": "daba67fd6ced800401acc92c269b702043cbe4053f694d8c1784572cb9710eae",
    "idcelular": "97fe33f6f301aa86",
    "modelo": "CONTAGEM",
    "nome_arquivo": "CONTAGEM_1_014_04671382000136_310820261700.zip",
    "serial": "eyJjbnBqcyI6WyIwNDY3MTM4MjAwMDEzNiIsIjA0NjcxMzgyMDAwMzA2Il0sIm5vbWVzIjpbIkdVSURBVVRPIiwiR3VpZGF1dG8gRGVww7NzaXRvIl0sImlkc19jZWx1bGFyIjpbImEzZTllM2EwYTQ2NTk2NTIiLCI5N2ZlMzNmNmYzMDFhYTg2Il0sInZhbGlkYWRlIjoiMjAyNi0wOS0wNCIsIm5vbWVfY2xpZW50ZSI6IkdVSURBVVRPLEd1aWRhdXRvIERlcMOzc2l0byIsInNxbF9zZXJ2aWRvciI6IkNFT1NPRlQtU0VSVjEiLCJzcWxfYmFuY28iOiJHVUlEQVVUTyIsInRpcG9fbGljZW5jYSI6IlBybyIsImdlcmFkb19lbSI6IjIwMjYtMDgtMzFUMTI6MDI6NTQtMDM6MDAifQ.SF-BQLrj-UGwdck8daN7Ft_wb6KM6nit1PgvJedQzaw",
    "timestamp": "2026-08-31T17:00:46",
    "versao": "26.08.31 rev. 1"
  }
}