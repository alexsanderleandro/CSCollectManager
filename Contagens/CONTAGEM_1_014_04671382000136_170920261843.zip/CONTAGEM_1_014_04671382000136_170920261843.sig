{
  "assinatura": "f57aae5fdac30c1231183a51c211e6b07c28f3c6639e0a3be72ba183473d7d21",
  "assinatura_rsa": "VTzKfKbSsEB44iHG+ttKlNu1TIwHhZ3FqimSIjHUSiEIOKSXIWSWB0BhvKC2V99tp891Zx427YKYmH7X1O269UZFnJZMldlWksxBcwMWS2nF3vPKKf5hRPyQi/Npg3mwpCzHO5e14fQi2SD77Hg9v09heIp3+DIyhdb52Axpi1gp8TOICFkyER+SiWxANXxh7CP2/ZGHii7SUlKaQqRZYzgXUNx55EpZuZPUrfreYYX3v15kDCluuIoR8fGxMMxWs6GVuVjChe3Hg616zJwSCTOIGY9pmcOcOLi6USY8V36DdPA8Und2vyQkEfYUIa+WWb9myyANZzI+BFCOR+3Duw==",
  "payload": {
    "algoritmo": "HMAC-SHA256",
    "algoritmo_rsa": "RSA-2048/PKCS1v15-SHA256",
    "cnpj": "04671382000136",
    "codempresa": "1",
    "codvendedor": "014",
    "hash_assinatura": "97b3be03e8b97741a4e4370516516b069e3e96da9440623513fe0e12a61d3f4d",
    "hash_db": "b85129efd6a23248e4a315a255f5f9bf0fa88f392a7386533483f37226942071",
    "hash_fotos": {},
    "hash_metricas": "",
    "hash_pdf": "115b556a6416bced9777db97d9ef2318beb63a517d4421aa9cf502b0981a47d7",
    "idcelular": "97fe33f6f301aa86",
    "modelo": "CONTAGEM",
    "nome_arquivo": "CONTAGEM_1_014_04671382000136_170920261843.zip",
    "serial": "eyJjbnBqcyI6WyIwNDY3MTM4MjAwMDEzNiIsIjA0NjcxMzgyMDAwMzA2Il0sIm5vbWVzIjpbIkdVSURBVVRPIiwiR3VpZGF1dG8gRGVww7NzaXRvIl0sImlkc19jZWx1bGFyIjpbImEzZTllM2EwYTQ2NTk2NTIiLCI5N2ZlMzNmNmYzMDFhYTg2Il0sInZhbGlkYWRlIjoiMjAyNi0wOS0xOSIsIm5vbWVfY2xpZW50ZSI6IkdVSURBVVRPLEd1aWRhdXRvIERlcMOzc2l0byIsInNxbF9zZXJ2aWRvciI6IkNFT1NPRlQtU0VSVjEiLCJzcWxfYmFuY28iOiJHVUlEQVVUTyIsInRpcG9fbGljZW5jYSI6IlBybyIsImdlcmFkb19lbSI6IjIwMjYtMDktMTRUMDk6MTY6MzctMDM6MDAifQ.b1R-1SpNCSV1eJRBf9qCUV-RV6kUYQxijmSzRwh0KIY",
    "timestamp": "2026-09-17T18:43:36",
    "versao": "26.09.17 rev. 2"
  }
}