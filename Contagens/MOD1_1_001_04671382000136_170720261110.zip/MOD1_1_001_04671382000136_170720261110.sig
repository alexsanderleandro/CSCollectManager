{
  "assinatura": "db30e0cf7b449d63cf3f7c52941778c966fc47448709fa3771b4de926f07f49d",
  "payload": {
    "algoritmo": "HMAC-SHA256",
    "cnpj": "04671382000136",
    "codempresa": "1",
    "codvendedor": "001",
    "hash_assinatura": "d6810c1896ee8c8c4e4828e496decb4c003f6a223c5809076ca2adeb76e1f17b",
    "hash_fotos": {},
    "hash_pdf": "677082a0518f79bc3dd47a6f4794f0d90434e8028661bbebe0199fb4c301470a",
    "hash_txt": "2b4429ec9b502d0684175b861e54834005ad5c659befd048d5bfce9fe0bf5150",
    "idcelular": "a3e9e3a0a4659652",
    "modelo": "MOD1",
    "nome_arquivo": "MOD1_1_001_04671382000136_170720261110.zip",
    "serial": "eyJjbnBqcyI6WyIwNDY3MTM4MjAwMDEzNiIsIjA0NjcxMzgyMDAwMzA2Il0sImlkc19jZWx1bGFyIjpbImEzZTllM2EwYTQ2NTk2NTIiLCJBTEVYU0FOREVSVEVTVEVJRCJdLCJ2YWxpZGFkZSI6IjIwMjYtMDctMzEiLCJub21lX2NsaWVudGUiOiJHVUlEQVVUTyIsInNxbF9zZXJ2aWRvciI6IkNFT1NPRlQtU0VSVjEiLCJzcWxfYmFuY28iOiJHVUlEQVVUTyIsImdlcmFkb19lbSI6IjIwMjYtMDctMDlUMTA6NDU6NDItMDM6MDAifQ.6ZmUsCZAS9tJIfmde_Ms2kR_wdGfyTW6kp_QzcqCUrc",
    "timestamp": "2026-07-17T11:10:50",
    "versao": "26.07.17 rev. 1"
  }
}