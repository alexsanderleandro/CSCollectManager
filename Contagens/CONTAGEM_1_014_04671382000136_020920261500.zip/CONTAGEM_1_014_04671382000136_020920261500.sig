{
  "assinatura": "51137d2ab65b53c0539b7059c940d0907b13bd02ea79486f02454a40bfa27be7",
  "assinatura_rsa": "GuIQkv0CSpEE1KWjGVFDRKWcSn+KOp+BH6Je52uMflOoUqIPxGv4KEGOnltdPovspM8nryYbaz0ooqUI1LMDF7XsIQy1cixaxVdeEcWoJ3JKKQEjecbWQb5LtBCwJh+a/OLy/X3p743h6TMXzT7d56e0/178zXhKWm4PPMr2dpxbp+9MuaYu/tu3J0WZtkg2B9arb8lxwrWjnUMySEkppPZWLZDbsh6t5hd1ba+gjqE9oPTMb/XtSzWPd+/XEFsXNHRl58StlaB7rdGjKvXw8okgU391zeL/XcvTlUuE6GwqjrvER0JQ/EVGz7jG00ZJpqdqTk9uHSdWL+dfkp8Amw==",
  "payload": {
    "algoritmo": "HMAC-SHA256",
    "algoritmo_rsa": "RSA-2048/PKCS1v15-SHA256",
    "cnpj": "04671382000136",
    "codempresa": "1",
    "codvendedor": "014",
    "hash_assinatura": "224d5b019eaf31d755c7000a32603406c7e70aa6490297b9d0f89385a708310d",
    "hash_db": "3c6d6a750f421abf5449e0fc983d7dde85e25ac4c2438df366710d30fc26f2ad",
    "hash_fotos": {},
    "hash_metricas": "dbbfb703dce4caff4d56a1c12af992c2781a9928232f2df5c836fa9adf82b709",
    "hash_pdf": "bfebe04c415a5abbf88d17599d1dade7583f5a697bb8129bc8041f8ab39e37ea",
    "idcelular": "97fe33f6f301aa86",
    "modelo": "CONTAGEM",
    "nome_arquivo": "CONTAGEM_1_014_04671382000136_020920261500.zip",
    "serial": "eyJjbnBqcyI6WyIwNDY3MTM4MjAwMDEzNiIsIjA0NjcxMzgyMDAwMzA2Il0sIm5vbWVzIjpbIkdVSURBVVRPIiwiR3VpZGF1dG8gRGVww7NzaXRvIl0sImlkc19jZWx1bGFyIjpbImEzZTllM2EwYTQ2NTk2NTIiLCI5N2ZlMzNmNmYzMDFhYTg2Il0sInZhbGlkYWRlIjoiMjAyNi0wOS0wNCIsIm5vbWVfY2xpZW50ZSI6IkdVSURBVVRPLEd1aWRhdXRvIERlcMOzc2l0byIsInNxbF9zZXJ2aWRvciI6IkNFT1NPRlQtU0VSVjEiLCJzcWxfYmFuY28iOiJHVUlEQVVUTyIsInRpcG9fbGljZW5jYSI6IlBybyIsImdlcmFkb19lbSI6IjIwMjYtMDgtMzFUMTI6MDI6NTQtMDM6MDAifQ.SF-BQLrj-UGwdck8daN7Ft_wb6KM6nit1PgvJedQzaw",
    "timestamp": "2026-09-02T15:00:11",
    "versao": "26.09.02 rev. 2"
  }
}