{
  "assinatura": "780512a7e4682fa3b351c7204ad35bd2db665fb77d8aa2b06747f5a67190c845",
  "assinatura_rsa": "M6Wgw9qV0krBaX6/znx3ur256FxrVsHnCrr7+aG4RmS09nLYgCIsZ9k/Pwt8ufntxg/Qpl6CGzZ2j6EbkDyTL/t/nyC/6kP+bEMZPL0u1sUmiW9oIThZMD9fMIOLy45A7lmYyMfWEdBtgk49AZ/G87qX6K9z24yVd6DovmbGL81Wlurr5njsMepisv608yAaHaVlBDZj9Dn9FHkzd7MuUq4czez679Cr0IakYd+iQK8ijQNFm11YnP4TodxwgSsVQIVyi3WAhERo3VOyc641wXFkX2IWyAMvTCxQ3ka3vngOMiosXyzEJSj4xTqEUG7hKsf6EgN3BlC55zpkP6cZ0A==",
  "payload": {
    "algoritmo": "HMAC-SHA256",
    "algoritmo_rsa": "RSA-2048/PKCS1v15-SHA256",
    "cnpj": "04671382000136",
    "codempresa": "1",
    "codvendedor": "014",
    "hash_assinatura": "208fd32c0e322569c4493a90c4f85bd0de67d64f71389db3dd0ac060d1a1c9bf",
    "hash_db": "5864f98a7c7092036d4e092f966bd8cdc3f9d9e865b0c64efcacf0d56b12bc42",
    "hash_fotos": {},
    "hash_metricas": "ed2c3ad87e22ded8183dd0f6b1e5c18c900b865a515eb5fb3e851a39be4956b6",
    "hash_pdf": "3f940bf3cb11d601f402988b8ede06028a321218384ac4eac1c5b348041ae9f9",
    "idcelular": "97fe33f6f301aa86",
    "modelo": "CONTAGEM",
    "nome_arquivo": "CONTAGEM_1_014_04671382000136_010920261616.zip",
    "serial": "eyJjbnBqcyI6WyIwNDY3MTM4MjAwMDEzNiIsIjA0NjcxMzgyMDAwMzA2Il0sIm5vbWVzIjpbIkdVSURBVVRPIiwiR3VpZGF1dG8gRGVww7NzaXRvIl0sImlkc19jZWx1bGFyIjpbImEzZTllM2EwYTQ2NTk2NTIiLCI5N2ZlMzNmNmYzMDFhYTg2Il0sInZhbGlkYWRlIjoiMjAyNi0wOS0wNCIsIm5vbWVfY2xpZW50ZSI6IkdVSURBVVRPLEd1aWRhdXRvIERlcMOzc2l0byIsInNxbF9zZXJ2aWRvciI6IkNFT1NPRlQtU0VSVjEiLCJzcWxfYmFuY28iOiJHVUlEQVVUTyIsInRpcG9fbGljZW5jYSI6IlBybyIsImdlcmFkb19lbSI6IjIwMjYtMDgtMzFUMTI6MDI6NTQtMDM6MDAifQ.SF-BQLrj-UGwdck8daN7Ft_wb6KM6nit1PgvJedQzaw",
    "timestamp": "2026-09-01T16:16:25",
    "versao": "26.09.01 rev. 1"
  }
}