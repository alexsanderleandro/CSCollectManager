{
  "assinatura": "ae4803955b2097387746bd6e348482cf7a596c064420293907b5c65ad99cad65",
  "assinatura_rsa": "TAeKPVcgGfVtIipL09zoSNUA86a3agMWnwWrf2V1zEs9uay0ABtDD6SASrUggHIMu3c78XFPc4oX/xDOtrOqIFaiUWnyBVG+aDnt9d2KUNUnY36+aMJb0nVN2Q1TexfUJW7DY9A0StEfzZ8NJmAmr9t8GJhorPZjxhxf7vEO5lIQ5SM+JNqapv1uzHG4MRiCfawFOpjRPl6AGaZfBxYCg0Nst4kE8OLDmsgNtlZOhT/ynUiIcgbEjXGHO2hT4DnVsjSJBfVswQsitHJPcic40Ij+qKsBoCG+ZQHQHjb4+7kwRXVGxy6HxszS8AoObeTBbosrFM1bQEmPR1OtLNZO+A==",
  "payload": {
    "algoritmo": "HMAC-SHA256",
    "algoritmo_rsa": "RSA-2048/PKCS1v15-SHA256",
    "cnpj": "04671382000306",
    "codempresa": "3",
    "codvendedor": "014",
    "hash_assinatura": "54dea2443054e15b9fe2903dd527cee9c14906f125d1c915f90fa80dcd821ce3",
    "hash_db": "e54d126068b8ccb3923a16497f9b49a982a2dfab7dbbd7106ae81ec34ba69ef9",
    "hash_fotos": {},
    "hash_metricas": "f8cc128b474bc2ae482e9913656a9ca730f5025b3c21028a53ecacd15345d675",
    "hash_pdf": "76f6608e291eaeb34ebec1b04e0d64b4146cc9d3d9e4308ae37dbd335bdf4ad6",
    "idcelular": "97fe33f6f301aa86",
    "modelo": "CONTAGEM",
    "nome_arquivo": "CONTAGEM_3_014_04671382000306_250820261457.zip",
    "serial": "eyJjbnBqcyI6WyIwNDY3MTM4MjAwMDEzNiIsIjA0NjcxMzgyMDAwMzA2Il0sIm5vbWVzIjpbIkdVSURBVVRPIiwiR3VpZGF1dG8gRGVww7NzaXRvIl0sImlkc19jZWx1bGFyIjpbImEzZTllM2EwYTQ2NTk2NTIiLCI5N2ZlMzNmNmYzMDFhYTg2Il0sInZhbGlkYWRlIjoiMjAyNi0wOC0yOCIsIm5vbWVfY2xpZW50ZSI6IkdVSURBVVRPLEd1aWRhdXRvIERlcMOzc2l0byIsInNxbF9zZXJ2aWRvciI6IkNFT1NPRlQtU0VSVjEiLCJzcWxfYmFuY28iOiJHVUlEQVVUTyIsInRpcG9fbGljZW5jYSI6IlBybyIsImdlcmFkb19lbSI6IjIwMjYtMDgtMjVUMDg6NTA6MzItMDM6MDAifQ.L6lTvieBYwvAZbA7BMgScmBjoI4cPCLVoETJ0qFe6EI",
    "timestamp": "2026-08-25T14:57:03",
    "versao": "26.08.23 rev. 2"
  }
}