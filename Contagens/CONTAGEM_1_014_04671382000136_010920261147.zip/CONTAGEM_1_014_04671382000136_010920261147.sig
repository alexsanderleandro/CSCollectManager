{
  "assinatura": "f0d3012596e35279828a3af0760f01382eed275e2f1f8b389fdda304c65b320f",
  "assinatura_rsa": "YaAWLjM97pXtdOzi+y2RYqrrPdkktVvFKMjq02bHh+SfpDWRrtetZcf4u/ccHviNgP+qaocjaxHw20N7FLrumCrIb7cMpbx0Ni9hrB3+49CGHTcMgyqjGxNHgT44xwrFgOZn5w5zk1sIVTmQ0SfrBTSnQ8prSc5BfTp7QuiMXJuupGOu71ObdpxisY726fDXWka72FiAAb3dxKw+RhxwbrFS3Ek0QVitFtKdRjT2IpU2Ioi6fELEsw44fKRdjH2ryCH4CGAVKkmfk/zNAEKNM6mTKMAWNTTUqh4zCL6cau/+KjpbuV+u1OvjWvKQYP3YyOK0c7UzkxVBfnGYoFA+Ow==",
  "payload": {
    "algoritmo": "HMAC-SHA256",
    "algoritmo_rsa": "RSA-2048/PKCS1v15-SHA256",
    "cnpj": "04671382000136",
    "codempresa": "1",
    "codvendedor": "014",
    "hash_assinatura": "3521e0f6c569e5ece5e16507a74263252bc75993591ab23e63724902323a89bc",
    "hash_db": "0ff247ea9bc1c08c3722c4aa59d58abb9bec4d927e2a8bde6ad2cd8ba2d3143a",
    "hash_fotos": {},
    "hash_metricas": "4d0278d15213695a80c34294bc61eb9ed5a2ceff4da921b606b12ed735888bad",
    "hash_pdf": "54481200e00f9f661c434506f72305db0e99d908805d14d5b5dcfd0130425627",
    "idcelular": "97fe33f6f301aa86",
    "modelo": "CONTAGEM",
    "nome_arquivo": "CONTAGEM_1_014_04671382000136_010920261147.zip",
    "serial": "eyJjbnBqcyI6WyIwNDY3MTM4MjAwMDEzNiIsIjA0NjcxMzgyMDAwMzA2Il0sIm5vbWVzIjpbIkdVSURBVVRPIiwiR3VpZGF1dG8gRGVww7NzaXRvIl0sImlkc19jZWx1bGFyIjpbImEzZTllM2EwYTQ2NTk2NTIiLCI5N2ZlMzNmNmYzMDFhYTg2Il0sInZhbGlkYWRlIjoiMjAyNi0wOS0wNCIsIm5vbWVfY2xpZW50ZSI6IkdVSURBVVRPLEd1aWRhdXRvIERlcMOzc2l0byIsInNxbF9zZXJ2aWRvciI6IkNFT1NPRlQtU0VSVjEiLCJzcWxfYmFuY28iOiJHVUlEQVVUTyIsInRpcG9fbGljZW5jYSI6IlBybyIsImdlcmFkb19lbSI6IjIwMjYtMDgtMzFUMTI6MDI6NTQtMDM6MDAifQ.SF-BQLrj-UGwdck8daN7Ft_wb6KM6nit1PgvJedQzaw",
    "timestamp": "2026-09-01T11:47:27",
    "versao": "26.09.01 rev. 1"
  }
}