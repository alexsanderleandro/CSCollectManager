{
  "assinatura": "d45fa813c5492bce87af368f68c41b17a37ccd7e7813c0677823c00f9d2e1d43",
  "assinatura_rsa": "uK6wjvEcuIZzo1QkrDynzt+W/bkj2oxuVJ/nkSykTNp5OIP+WQDhHu6MhGFD93t474jGROQ3oAfNlFAFlkjm2ZMuJVSC9s5lvrQIFxiWpC/qds8/SeZGdNnLw5TIBBlziRUc+eNcktDTTs5/w2sh/YI7mnSjMhsRkaUhAJC9VMF+wZGHS3nyTDGJ2Uk5tzM1wwmfYgMtXvBdA0i7EOO10Wu31RZs3Z9XEx3Woeddl08lS0ER5Nt3eGsJF6PXZCSgd4ifgzMOyhcX4+/6jUUDKyG/B1Q2ji+0K5SNv9ywsatA40L3UoNdSNwkkIShltNQQrX8BfvTfwhLoT2br4yNdg==",
  "payload": {
    "algoritmo": "HMAC-SHA256",
    "algoritmo_rsa": "RSA-2048/PKCS1v15-SHA256",
    "cnpj": "04671382000136",
    "codempresa": "1",
    "codvendedor": "014",
    "hash_assinatura": "404f4c32775491a8deea21aeefb51392e9ac8359ebb49a1d6c91ceff20d3129d",
    "hash_db": "d099cc736a98c6d90554e0403988013dc89ac88354af2f805d784a27cd0b6216",
    "hash_fotos": {},
    "hash_metricas": "b610977cc67177fa3abd21c1eedd3cd8706400b0ea8a6afdc5461f95ab40a3d3",
    "hash_pdf": "d088ac6015ee5b0291fbef5103284db382588c81beea959da9c024831b2524e0",
    "idcelular": "97fe33f6f301aa86",
    "modelo": "CONTAGEM",
    "nome_arquivo": "CONTAGEM_1_014_04671382000136_020920261710.zip",
    "serial": "eyJjbnBqcyI6WyIwNDY3MTM4MjAwMDEzNiIsIjA0NjcxMzgyMDAwMzA2Il0sIm5vbWVzIjpbIkdVSURBVVRPIiwiR3VpZGF1dG8gRGVww7NzaXRvIl0sImlkc19jZWx1bGFyIjpbImEzZTllM2EwYTQ2NTk2NTIiLCI5N2ZlMzNmNmYzMDFhYTg2Il0sInZhbGlkYWRlIjoiMjAyNi0wOS0wNCIsIm5vbWVfY2xpZW50ZSI6IkdVSURBVVRPLEd1aWRhdXRvIERlcMOzc2l0byIsInNxbF9zZXJ2aWRvciI6IkNFT1NPRlQtU0VSVjEiLCJzcWxfYmFuY28iOiJHVUlEQVVUTyIsInRpcG9fbGljZW5jYSI6IlBybyIsImdlcmFkb19lbSI6IjIwMjYtMDgtMzFUMTI6MDI6NTQtMDM6MDAifQ.SF-BQLrj-UGwdck8daN7Ft_wb6KM6nit1PgvJedQzaw",
    "timestamp": "2026-09-02T17:10:52",
    "versao": "26.09.02 rev. 4"
  }
}