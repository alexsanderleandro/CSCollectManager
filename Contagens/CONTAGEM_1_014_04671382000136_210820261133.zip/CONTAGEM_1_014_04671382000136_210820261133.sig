{
  "assinatura": "690e8a1f808a50d54293c6403c476c59f3a794c1daccfcfd89ed917695eb6dc6",
  "assinatura_rsa": "aPnbUfnO+DPZdsAv6PLexJIx9VAXkxhs8UjtxRCycNBiUgz6jw6GyLb32MGDvBwqjWZuw1zO+w1FDFm3pBNgPPLvbn0pWYfE7CDNtzo8vELVQFDr72xumYvDqo4IyfOn21PEOUSEAusKnOg0DAAITjIVkb1g0fuyxcDaYNu51Lz9FP1dvSDrGXV18TWm7KHFMEmuB5EvNBxNvHQYImj4CuuiS40GhN4AHILDADmElvxmReQnn3CKcmoF2GQwu7MD5FGiFkLEM5kzWFLtAMZSPudSGWihf6hlQlY62Iht3UsgpO3K/tYRNp/1ncHj/QFdSJBcYeZicjOH+CFhjKZM8A==",
  "payload": {
    "algoritmo": "HMAC-SHA256",
    "algoritmo_rsa": "RSA-2048/PKCS1v15-SHA256",
    "cnpj": "04671382000136",
    "codempresa": "1",
    "codvendedor": "014",
    "hash_assinatura": "3ba478bb8aece8513a343cb3481cede82d96be6baac0e6bc64575682b9469753",
    "hash_db": "dce0d92494d1fc6ad12832356ed268fdf962970782173295e5fe8083803a6cb6",
    "hash_fotos": {},
    "hash_metricas": "a1b637057efe5b4461d6e8352e16266e68c03b2f4971b7a588dc600c18da27b2",
    "hash_pdf": "fe1a71498f443b3b3b495549160351af6ff720558df9f51f208f9390d6ee8ce9",
    "idcelular": "97fe33f6f301aa86",
    "modelo": "CONTAGEM",
    "nome_arquivo": "CONTAGEM_1_014_04671382000136_210820261133.zip",
    "serial": "eyJjbnBqcyI6WyIwNDY3MTM4MjAwMDEzNiIsIjA0NjcxMzgyMDAwMzA2Il0sIm5vbWVzIjpbIkdVSURBVVRPIiwiR3VpZGF1dG8gRGVww7NzaXRvIl0sImlkc19jZWx1bGFyIjpbImEzZTllM2EwYTQ2NTk2NTIiLCI5N2ZlMzNmNmYzMDFhYTg2Il0sInZhbGlkYWRlIjoiMjAyNi0wOC0yMSIsIm5vbWVfY2xpZW50ZSI6IkdVSURBVVRPLEd1aWRhdXRvIERlcMOzc2l0byIsInNxbF9zZXJ2aWRvciI6IkNFT1NPRlQtU0VSVjEiLCJzcWxfYmFuY28iOiJHVUlEQVVUTyIsInRpcG9fbGljZW5jYSI6IlBybyIsImdlcmFkb19lbSI6IjIwMjYtMDgtMTdUMTU6NTI6MzgtMDM6MDAifQ.RI__GqlWteXYgAFoWOT43UHojyQbVM1WOe9Nan3yVR0",
    "timestamp": "2026-08-21T11:33:51",
    "versao": "26.08.21 rev. 1"
  }
}