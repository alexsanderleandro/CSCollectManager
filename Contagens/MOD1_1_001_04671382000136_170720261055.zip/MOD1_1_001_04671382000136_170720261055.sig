{
  "assinatura": "b60b124f485f2b8bdf04123edf7e0dda4533d79995be9f6964d55dee48118f52",
  "payload": {
    "algoritmo": "HMAC-SHA256",
    "cnpj": "04671382000136",
    "codempresa": "1",
    "codvendedor": "001",
    "hash_assinatura": "3e5e4503a0caad7ce0b341256ae7dfea5f5fd3eb0504f193038c3ad08524f479",
    "hash_fotos": {},
    "hash_pdf": "f3812d7273549714db32976698af566093ad3f976d23bd00e1f01d3afd5dabb8",
    "hash_txt": "2b4429ec9b502d0684175b861e54834005ad5c659befd048d5bfce9fe0bf5150",
    "idcelular": "a3e9e3a0a4659652",
    "modelo": "MOD1",
    "nome_arquivo": "MOD1_1_001_04671382000136_170720261055.zip",
    "serial": "eyJjbnBqcyI6WyIwNDY3MTM4MjAwMDEzNiIsIjA0NjcxMzgyMDAwMzA2Il0sImlkc19jZWx1bGFyIjpbImEzZTllM2EwYTQ2NTk2NTIiLCJBTEVYU0FOREVSVEVTVEVJRCJdLCJ2YWxpZGFkZSI6IjIwMjYtMDctMzEiLCJub21lX2NsaWVudGUiOiJHVUlEQVVUTyIsInNxbF9zZXJ2aWRvciI6IkNFT1NPRlQtU0VSVjEiLCJzcWxfYmFuY28iOiJHVUlEQVVUTyIsImdlcmFkb19lbSI6IjIwMjYtMDctMDlUMTA6NDU6NDItMDM6MDAifQ.6ZmUsCZAS9tJIfmde_Ms2kR_wdGfyTW6kp_QzcqCUrc",
    "timestamp": "2026-07-17T10:55:35",
    "versao": "26.07.17 rev. 1"
  }
}