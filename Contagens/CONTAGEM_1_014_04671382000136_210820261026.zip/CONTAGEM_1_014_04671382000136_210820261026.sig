{
  "assinatura": "b3a79c82a82861410f89b1c32b8c0b568722766db72251b6022939b7789ed897",
  "assinatura_rsa": "h1J6il/eDEsnampY32B4jn07fDk5ONSc+nv/3vtA74fYzRaJm/wJISVB9XRjRXM68zGh0anI/ruqEJ4zTsapWKnHbX/93A0oWDlrjFtz3jxyh6W0nKBFN2vfs2thR7f41hjvf6mpkA1F/vyjltqjNm2z9zbiTxDjZst/K5RmNt4cLYfabrbUDSxwAIjWOajUYxvaFRgkgI4sXXzFEbAFQig1cfbx0qiB58pqqFi7cV9fMNCKqtdfQtg5ZhPICpzjgkltjdr9tUGVIY0Rtc7mb23owc3FmFsYdmLzfolmlJtQhFqd+iwzY2bhyrDfnUZMAA7CtYkL8Y/OpOBit9l8rQ==",
  "payload": {
    "algoritmo": "HMAC-SHA256",
    "algoritmo_rsa": "RSA-2048/PKCS1v15-SHA256",
    "cnpj": "04671382000136",
    "codempresa": "1",
    "codvendedor": "014",
    "hash_assinatura": "7f840a124743f72b5eec7e13606bd2642029dfe04521b7664c8f0bb884b739a5",
    "hash_db": "35ade85f8c935db4feac19a7a539d2dfac010842157dfb72557a5e691b6d6cdf",
    "hash_fotos": {},
    "hash_metricas": "6b4ad9724aa86270066199c88dac79e9c295affbfb54f86a0e2c919dfae8a9fa",
    "hash_pdf": "7818d3b676c60034b97dd43425da66c211defa3f09d6c672b5bca82d70a03069",
    "idcelular": "97fe33f6f301aa86",
    "modelo": "CONTAGEM",
    "nome_arquivo": "CONTAGEM_1_014_04671382000136_210820261026.zip",
    "serial": "eyJjbnBqcyI6WyIwNDY3MTM4MjAwMDEzNiIsIjA0NjcxMzgyMDAwMzA2Il0sIm5vbWVzIjpbIkdVSURBVVRPIiwiR3VpZGF1dG8gRGVww7NzaXRvIl0sImlkc19jZWx1bGFyIjpbImEzZTllM2EwYTQ2NTk2NTIiLCI5N2ZlMzNmNmYzMDFhYTg2Il0sInZhbGlkYWRlIjoiMjAyNi0wOC0yMSIsIm5vbWVfY2xpZW50ZSI6IkdVSURBVVRPLEd1aWRhdXRvIERlcMOzc2l0byIsInNxbF9zZXJ2aWRvciI6IkNFT1NPRlQtU0VSVjEiLCJzcWxfYmFuY28iOiJHVUlEQVVUTyIsInRpcG9fbGljZW5jYSI6IlBybyIsImdlcmFkb19lbSI6IjIwMjYtMDgtMTdUMTU6NTI6MzgtMDM6MDAifQ.RI__GqlWteXYgAFoWOT43UHojyQbVM1WOe9Nan3yVR0",
    "timestamp": "2026-08-21T10:26:28",
    "versao": "26.08.20 rev. 2"
  }
}