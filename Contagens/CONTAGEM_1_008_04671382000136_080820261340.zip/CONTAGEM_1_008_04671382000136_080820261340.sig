{
  "assinatura": "62767c96ee1d07c528358b5f87182320ace0dcac5ca53b4f9352e63890b3298a",
  "assinatura_rsa": "uA3TgbPr1+ZHujloDcXXRVxFpuS+Sw8OENb9ietsyHFYHoTVmUZi4O1/DHcPHy8hEsVajaCAAhzaSD3qWrxWa5WfZg9Q+SlKg4LwxfehkPz+1QPSIjeZkEnxZebn2YE/QfLMCeSwAfgy9MfG+6nKgXlyV8ZTWijjagdTYMCrglsUItPURlan1/CPkab5c+ayH97LPpOzHyb81r9J9eGQ5RK7UYBQ/xmY01n6iifdPvT4rVwLfU+o0uQBZ9HAWgNCFvfizfOhJLQ4C1pbbaktYnxiku67qXfF66ZLKNHExIlvk+wkNlG3C86UjXsakBNiyI979dPaou2cN0Cl765hJg==",
  "payload": {
    "algoritmo": "HMAC-SHA256",
    "algoritmo_rsa": "RSA-2048/PKCS1v15-SHA256",
    "cnpj": "04671382000136",
    "codempresa": "1",
    "codvendedor": "008",
    "hash_assinatura": "4a4f8ff987b39d5ca629464a64060adee75fa17c6ef1c53b88dea324f55f8f9a",
    "hash_db": "a9ac4d80a7e19ee7a22cbeb9db9075fef79cc6cfcab1744f6a329a298eb28633",
    "hash_fotos": {},
    "hash_metricas": "fc5b6105bc812035b9dfe632bc1533aad6cef64a5d21dc2b61ae93ebf5b01a50",
    "hash_pdf": "d7ffae4177b8100e0cdb26317669c9248a4e276ba0fb0cc8c59b762be5004867",
    "idcelular": "97fe33f6f301aa86",
    "modelo": "CONTAGEM",
    "nome_arquivo": "CONTAGEM_1_008_04671382000136_080820261340.zip",
    "serial": "eyJjbnBqcyI6WyIwNDY3MTM4MjAwMDEzNiIsIjA0NjcxMzgyMDAwMzA2Il0sIm5vbWVzIjpbIkdVSURBVVRPIiwiR3VpZGF1dG8gRGVww7NzaXRvIl0sImlkc19jZWx1bGFyIjpbImEzZTllM2EwYTQ2NTk2NTIiLCI5N2ZlMzNmNmYzMDFhYTg2Il0sInZhbGlkYWRlIjoiMjAyNi0wOC0xNCIsIm5vbWVfY2xpZW50ZSI6IkdVSURBVVRPLEd1aWRhdXRvIERlcMOzc2l0byIsInNxbF9zZXJ2aWRvciI6IkNFT1NPRlQtU0VSVjEiLCJzcWxfYmFuY28iOiJHVUlEQVVUTyIsInRpcG9fbGljZW5jYSI6IlBybyIsImdlcmFkb19lbSI6IjIwMjYtMDgtMDdUMTM6Mjk6MzAtMDM6MDAifQ.x0GNmSaN1iL8RDnyM_9oohCVWKbQhxgUeH3JQLVOkYw",
    "timestamp": "2026-08-08T13:40:45",
    "versao": "26.08.07 rev. 5"
  }
}