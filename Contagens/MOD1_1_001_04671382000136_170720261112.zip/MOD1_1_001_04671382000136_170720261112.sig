{
  "assinatura": "a8dda0f1c9f1704a31c2e4ffb61bd90352e5ce3f8bad90708aad4fa972acc6f3",
  "payload": {
    "algoritmo": "HMAC-SHA256",
    "cnpj": "04671382000136",
    "codempresa": "1",
    "codvendedor": "001",
    "hash_assinatura": "9d6eb6fb9ee25b766c2035717ad8d4c911b630d3382f4ee38ce681963a56879c",
    "hash_fotos": {},
    "hash_pdf": "c248d0fdaed5aff625b3626ff7ca31a4176e3911259874f5ea6b0b5b85c3b253",
    "hash_txt": "2b4429ec9b502d0684175b861e54834005ad5c659befd048d5bfce9fe0bf5150",
    "idcelular": "a3e9e3a0a4659652",
    "modelo": "MOD1",
    "nome_arquivo": "MOD1_1_001_04671382000136_170720261112.zip",
    "serial": "eyJjbnBqcyI6WyIwNDY3MTM4MjAwMDEzNiIsIjA0NjcxMzgyMDAwMzA2Il0sImlkc19jZWx1bGFyIjpbImEzZTllM2EwYTQ2NTk2NTIiLCJBTEVYU0FOREVSVEVTVEVJRCJdLCJ2YWxpZGFkZSI6IjIwMjYtMDctMzEiLCJub21lX2NsaWVudGUiOiJHVUlEQVVUTyIsInNxbF9zZXJ2aWRvciI6IkNFT1NPRlQtU0VSVjEiLCJzcWxfYmFuY28iOiJHVUlEQVVUTyIsImdlcmFkb19lbSI6IjIwMjYtMDctMDlUMTA6NDU6NDItMDM6MDAifQ.6ZmUsCZAS9tJIfmde_Ms2kR_wdGfyTW6kp_QzcqCUrc",
    "timestamp": "2026-07-17T11:12:16",
    "versao": "26.07.17 rev. 1"
  }
}