{
  "assinatura": "1a75f90bc396019194508bb40f0ae9eaeefa7d7d499c8fdfc99c29a905c2ffd5",
  "assinatura_rsa": "sdUAKOvDDfBLQ+x1IqhlO1+8NdlzBjVfBt64J4kksYvrYEgGWVMHQagpf8qiiVm0VF2m+vfcL0aCLBLNh4U5DBdTACjsRMFt53c4oKv0XQiBKuTzHTCVD6QcCiGfV5PATgBU4P8/JCc4oWSqDLZBdWZEWGHcRwCt7Q4+TjgdPv326hnIPYNRnGnUzGuiX0Z1TN5+WyVt1CSHd7fcAXC6lO4RXL0zqNU1+lxT0VPqnDnNKVxENzqMnSk3P6Gdc1xzqbQDEkQuDz5MMHVF3YA6eenF/wZcDJLTAlYRJMc/PV37FGFXIpBR0H9rK/DO9VzvsNiqJk0vqCdAPswuvDqhBg==",
  "payload": {
    "algoritmo": "HMAC-SHA256",
    "algoritmo_rsa": "RSA-2048/PKCS1v15-SHA256",
    "cnpj": "04671382000136",
    "codempresa": "1",
    "codvendedor": "014",
    "hash_assinatura": "feb80b7510dd485606cd1de4d0440af0fc4ec386f1419f9fcf09179c67342e8a",
    "hash_db": "1cc23dffb20cd29cd8de5f459063877b7de50ec6d05fef7e368fdb631626cb15",
    "hash_fotos": {},
    "hash_metricas": "d121bb4eafb84e06e8e8b0321de2ab51ae92855ac75778434c6a44714e2dece7",
    "hash_pdf": "2b3f69d8549db3f168a559f8ccff9567b08d8e93f32723abb9a9ea6c5c9a0b1d",
    "idcelular": "97fe33f6f301aa86",
    "modelo": "CONTAGEM",
    "nome_arquivo": "CONTAGEM_1_014_04671382000136_020920260922.zip",
    "serial": "eyJjbnBqcyI6WyIwNDY3MTM4MjAwMDEzNiIsIjA0NjcxMzgyMDAwMzA2Il0sIm5vbWVzIjpbIkdVSURBVVRPIiwiR3VpZGF1dG8gRGVww7NzaXRvIl0sImlkc19jZWx1bGFyIjpbImEzZTllM2EwYTQ2NTk2NTIiLCI5N2ZlMzNmNmYzMDFhYTg2Il0sInZhbGlkYWRlIjoiMjAyNi0wOS0wNCIsIm5vbWVfY2xpZW50ZSI6IkdVSURBVVRPLEd1aWRhdXRvIERlcMOzc2l0byIsInNxbF9zZXJ2aWRvciI6IkNFT1NPRlQtU0VSVjEiLCJzcWxfYmFuY28iOiJHVUlEQVVUTyIsInRpcG9fbGljZW5jYSI6IlBybyIsImdlcmFkb19lbSI6IjIwMjYtMDgtMzFUMTI6MDI6NTQtMDM6MDAifQ.SF-BQLrj-UGwdck8daN7Ft_wb6KM6nit1PgvJedQzaw",
    "timestamp": "2026-09-02T09:22:29",
    "versao": "26.09.01 rev. 1"
  }
}