{
  "assinatura": "bf6fe858517b98f22c91343662a270b60c3fc3ef5978394870d0af6007d5ac7d",
  "payload": {
    "algoritmo": "HMAC-SHA256",
    "cnpj": "65381113000120",
    "codempresa": "1",
    "codvendedor": "043",
    "hash_assinatura": "3c3357a1b8b76139cbe28ace0e87ac03848c6ea7456d26c57a16e80fcc0250db",
    "hash_fotos": {},
    "hash_pdf": "aa2319a0b9c437b5825d72aa9a5900e3e7f271f0f1db64bb65f52b3d901baabe",
    "hash_txt": "c0298ad1b8cc3074e8c3378870378e56aa6d3c46158349007b22ce55001963e2",
    "idcelular": "a3e9e3a0a4659652",
    "modelo": "MOD1",
    "nome_arquivo": "MOD1_1_043_65381113000120_080520261413.zip",
    "serial": "d2bd9a450500c2e851d049c5fb846f44.KR9BAHRkz4EN_WDZmCM8uEChuNj6DYpGvzZG-csxmdE",
    "timestamp": "2026-05-08T14:13:15",
    "versao": "26.05.08 rev. 1"
  }
}